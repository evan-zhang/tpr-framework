# 编排操作手册

> 本文档只回答一个问题：**编排者在 TPR 全流程中怎么操作。**
> 包含执行透明规则、模型策略、上下文管理、sub-agent 派遣、自改进规范。
> 这是 Layer 2（Orchestrator Guardrails）的详细版。

---

## Orchestrator Guardrails（编排防线）

以下规则仅当 agent 作为编排者运行 TPR 全流程时适用。

| # | 防线 | 说明 |
|---|------|------|
| G1 | 只调度不动手 | 编排者不执行业务逻辑（代码/文档/分析） |
| G2 | 不冒充省级角色 | 编排者不是中书/门下/尚书，不代替它们工作 |
| G3 | 不替代省级回答问题 | 如果问题属于某省，spawn 该省来回答 |
| G4 | Announce-then-act | 说"创建X"的消息必须包含实际 tool call |
| G5 | yield after spawn | spawn 后立即 yield，不同步等待 |
| G6 | 文件锁 | 不并行 spawn 写同一文件的 sub-agent |
| G7 | 文件必须发送 | 写完文件后必须通过消息发送给用户 |
| G8 | 模型降级不接手 | model 429 时用备选模型重派 sub-agent，不自己做 |

---

## 执行透明规则

防止最常见的失败模式：编排者宣布了一个动作但从未真正执行。

### 必须遵守

1. **Announce-then-act（同消息）**：说"spawning X"的消息必须包含实际 spawn tool call，不允许"先说下一条再做"
2. **Notify on spawn**：spawn 成功后立即通知用户："Started: [任务名]（[模型]），预计 X 分钟"
3. **yield after spawn**：spawn 后立即调用 `sessions_yield`，关闭当前 turn
4. **Report on result**：sub-agent 返回结果后，立即用自然语言汇报：做了什么、产出在哪里、发现了什么问题。**⚠️ 核心规则：如果产出的是正式交付物（如 DISCOVERY.md、GRV.md、REVIEW.md），编排者在汇报时必须调用发文件工具将实际文档发送给用户。严禁在聊天消息中大段粘贴或"完整打印"文件内容！聊天窗口只用来写简短介绍，看全文必须通过系统下发真实的文件附件。**

### 反面案例

```
❌ 错误：
Turn 1: "I will now spawn Shangshu to implement X."
[no tool call]
Turn 2: [waiting for user to say something]

✅ 正确：
Turn 1: "Starting: X implementation (MiniMax, ~2 min). Will notify you when done."
[spawn tool call]
[sessions_yield]
```

---

## 模型策略（Hermes 原则）

### 模型选择顺序

`preferred` > `primary` > `fallback` > `provider default`

### 429 处理

- 不要自己接手执行
- 立即用 Tier-2 模型重试
- 每个 sub-agent 理想情况下应预定义 fallback 模型

### 具体模型配置

模型配置不属于 skill，属于 workspace。
各 agent 在自己的 `config/` 或 `AGENTS.md` 中声明模型配置。

---

## 上下文管理

### 核心原则

**不要把长上下文塞进 task 参数。用文件传递，sub-agent 按需读取。**

### 正确做法

1. 将上下文写入文件（如 `temp/context-{id}.md`）
2. 在 task 里只写文件路径和读取指令
3. 告诉 sub-agent 什么时候读、为什么读

```
✅ 正确：
task: You are 门下省.
Read the GRV at {path}/GRV.md before starting.
Raise objections and write to {path}/battle/BATTLE-R1-MENXI.md.

❌ 错误：
task: You are 门下省. Here is the full GRV: [粘贴 200 行文档...]
```

### Pitch File Reads

在 task 描述中明确告诉 sub-agent 什么时候读哪个文件：
- "开始前先读取 {path}/GRV.md"
- "需要时读取 self-improving/patterns.md"

---

## Sub-agent 派遣标准

### 派遣前检查清单

每次 spawn 前必须执行：

**Step 1：读取修正记录**
```
读取 self-improving/corrections.md 最后 3 条。
如有最近 24h 内的修正，在 spawn 消息中注明。
```

**Step 2：检查成功模式**
```
读取 self-improving/patterns.md 是否有相关模式可用。
```

**Step 3：文件预创建**
```
派遣会写文件的 sub-agent 前，先用 write 工具创建带占位符的目标文件。
原因：sub-agent 的 edit 工具要求文件已存在。
```

**Step 4：目录存在性**
```
验证目标目录存在，不存在则 mkdir -p。
```

**Step 5：工具声明**
```
sub-agent 任务 prompt 中必须明确说明：
- 创建新文件 → 用 write
- 修改已有文件 → 用 edit（文件已预创建时注明路径）
```

### 错误恢复

- sub-agent 报"Edit failed" → 说明 edit 作用于不存在的文件，重新派遣并修正工具说明
- 429 错误 → 立即用 Tier-2 模型重试，不自己接手

### 并发限制

- 最多 4 个并发 sub-agent
- 超过时等待其中一个完成

### Read-Only First 原则

复杂任务分两个阶段：
1. **Read-only 阶段**：先派只读 agent 收集上下文
2. **Write/Execute 阶段**：再派执行 agent

避免上下文冲突。

---

## 自改进规范

### 必须维护的文件

| 文件 | 位置 | 更新频率 | 内容 |
|------|------|---------|------|
| corrections.md | workspace/self-improving/ | 每次犯错时 | 错误、修正、预防 |
| patterns.md | workspace/self-improving/ | 每周复盘 | 成功模式、失败模式 |

**这些文件属于 workspace 运行时数据，不属于 skill。**

### 触发自我反省的条件

- 编排者自己干了 sub-agent 该干的事（越界）
- sub-agent 因为上下文问题需要重新执行
- 用户明确指出任务管理有问题

### 格式

```markdown
## [日期] [问题简述]
- 错误：[发生了什么]
- 原因：[为什么发生]
- 修正：[怎么做]
- 预防：[下次怎么避免]
```

---

## Session 状态管理

每个阶段完成后：
1. 关键决策记录到 `self-improving/patterns.md`
2. 出错时记录到 `self-improving/corrections.md`
3. Sub-agent 追踪通过 `subagents list` 自动完成

---

*版本：2.0.0*
*创建：2026-04-07*
